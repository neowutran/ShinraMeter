######### README #############

* Make sure you have installed .NET 4.6 or later
* Install WinPcap from https://www.winpcap.org/install/default.htm
* Launch the Damage Meter before connecting to Tera, or it won't detect the connection.
* Wiki: https://github.com/neowutran/TeraDamageMeter/wiki
