######### README #############
Tera Damage Meter by Gothos & neowutran

* RUN AS ADMINISTRATOR
* Make sure you have installed .NET 4.0 or later
* Install WinPcap from https://www.winpcap.org/install/default.htm
* Launch the Damage Meter before connecting to Tera, or it won't detect the connection.

Hotkey: 
Paste => Home
Copy => End
Reset => Suppr/Del