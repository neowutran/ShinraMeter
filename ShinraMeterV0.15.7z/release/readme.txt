######### README #############
Original Tera Damage Meter by Gothos: https://github.com/gothos-folly/TeraDamageMeter
This is a personnal fork of this project: https://github.com/neowutran/TeraDamageMeter/

* Make sure you have installed .NET 4.0 or later
* Install WinPcap from https://www.winpcap.org/install/default.htm
* Launch the Damage Meter before connecting to Tera, or it won't detect the connection.

#### !!!!!!!!! IMPORTANT !!!!!!!!!! #########
READ THIS https://github.com/neowutran/TeraDamageMeter/wiki
#### !!!!!!!!!!!!!!!!!!!!!!!!!!!!!! #########